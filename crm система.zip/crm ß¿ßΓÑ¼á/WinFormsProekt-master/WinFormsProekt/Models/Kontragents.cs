﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsProekt.Models
{
    public class Kontragents
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
